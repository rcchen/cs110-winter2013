#include <stdio.h>
#include <assert.h>

#include "inode.h"
#include "diskimg.h"



/*
 * Fetch the specified inode from the filesystem. 
 * Return 0 on success, -1 on error.  
 */
int
inode_iget(struct unixfilesystem *fs, int inumber, struct inode *inp)
{
  fprintf(stderr, "inode_get(inumber=%d) not implemented, returning -1\n", inumber);
  return -1;  
  
}

/*
 * Get the location of the specified file block of the specified inode.
 * Return the disk block number on success, -1 on error.  
 */
int
inode_indexlookup(struct unixfilesystem *fs, struct inode *inp, int blockNum)
{
  fprintf(stderr, "inode_indexlookup(blockNum=%d) not implemented, returning -1\n", blockNum);
  return -1;
}

/* 
 * Compute the size of an inode from its size0 and size1 fields.
 */
int
inode_getsize(struct inode *inp) 
{
  return ((inp->i_size0 << 16) | inp->i_size1); 
}
